DOC = "

Exercise 5:

Using the same technique, determine whether or not female weights appear to come from a normal distribution.

"
script_num = 5
script_intro(paste("Exercise",script_num))




prompt = "Using the same technique, determine whether or not female weights appear to come from a normal distribution."
cat(blue("Exercise "%+%red$bold(script_num) %+%":\n"), 
    magenta(prompt), sep="")



script_outro(paste("Exercise",script_num))