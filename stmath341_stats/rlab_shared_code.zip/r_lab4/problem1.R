DOC = "

1) Now let's consider some of the other variables in the body dimensions data set. 
Using the figures at the end of the exercises, match the histogram to its normal probability plot. 
All of the variables have been standardized (first subtract the mean, then divide by the standard deviation), 
so the units won't be of any help. If you are uncertain based on these figures, generate the plots in 
R to check.

a. The histogram for female biiliac (pelvic) diameter (bii.di) belongs to normal probability plot letter ____.

b. The histogram for female elbow diameter (elb.di) belongs to normal probability plot letter ____.

c. The histogram for general age (age) belongs to normal probability plot letter ____.

d. The histogram for female chest depth (che.de) belongs to normal probability plot letter ____.

"
fbiidimean <- mean(fdims$bii.di)
fbiidisd <- sd(fdims$bii.di)
biidiqqnrm <- qqnorm((fdims$bii.di-fbiidimean)/fbiidisd,ylim = c(min((fdims$bii.di-fbiidimean)/fbiidisd)*.8,
                                                                 max((fdims$bii.di-fbiidimean)/fbiidisd)*1.1))
biidiqqln <- qqline((fdims$bii.di-fbiidimean)/fbiidisd)

cat(green("fbiidimean <- mean(fdims$bii.di)\n"))
print(fbiidimean)
cat(green("fbiidisd <- sd(fdims$bii.di)\n"))
print(fbiidisd)


cat(green("sim_bidii_norm <- rnorm(n = length(fdims$bii.di), mean = fbiidimean, sd = fbiidisd)\n"))
sim_bidii_norm <- rnorm(n = length(fdims$bii.di), mean = fbiidimean, sd = fbiidisd)